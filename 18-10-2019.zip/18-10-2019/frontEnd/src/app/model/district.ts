export class District {
    district_id:number;
    state_id:number;
    district_name:string;
}
