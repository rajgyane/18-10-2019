export class Module {
    module_id:string;
    module_name:string;
    module_status:string;
}
