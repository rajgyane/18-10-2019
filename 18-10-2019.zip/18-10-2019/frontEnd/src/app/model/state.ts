export class State {
    state_id:number;
    state_code:string;
    state_name:string;
    status:number;
    region:string;
    Country_code:string;
}
