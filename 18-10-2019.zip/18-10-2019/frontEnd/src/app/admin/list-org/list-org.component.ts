import { Component, OnInit,ViewChild,Inject } from '@angular/core';
import { ServicesService} from '../../auth/services.service';
import  {List_org}  from '../../model/list_org';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { DialogboxComponent } from '../dialogbox/dialogbox.component';
import { MessageboxComponent} from '../messagebox/messagebox.component';



@Component({
  selector: 'app-list-org',
  templateUrl: './list-org.component.html',
  styleUrls: ['./list-org.component.css']
})
export class ListOrgComponent implements OnInit {
  
  list_org:List_org[]= [];
  dataSource: MatTableDataSource<List_org>;
@ViewChild(MatSort,{static: true}) sort: MatSort;
@ViewChild(MatPaginator,{static: true}) paginator: MatPaginator;
role_type:string;
displayedColumns: string[] = ['srno','full_name_org', 'org_aliase', 'logo', 'address','status','actions'];
show = true;

private postsSub: Subscription;
private authStatusSub: Subscription;
  constructor(private ls:ServicesService,private route: ActivatedRoute,
    private router: Router,public dialog: MatDialog) { }
    
  ngOnInit() {
    this.role_type=localStorage.getItem('assign_role');
    this.postsSub =this.ls
      .list_org()
      .subscribe((data: List_org[]) => {
        this.list_org = data;
        this.show = false;
        console.log(this.list_org);
        this.dataSource = new MatTableDataSource(this.list_org);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
        
    });
    
    
   

  }
  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }
  delete_org(id)
  {
    //console.log(id);
   
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width='300px';
    dialogConfig.height='250px';

    dialogConfig.data = {
    id: 1,
    title: 'Confirmation Box',question:'Do you want to remove ?'

    };
    const dialogConfig1 = new MatDialogConfig();
    dialogConfig1.disableClose = true;
    dialogConfig1.autoFocus = true;
    dialogConfig1.width='350px';
    dialogConfig1.height='250px';

    const dialogRef = this.dialog.open(DialogboxComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(result => {
    if(result==true)
    {
      //console.log(id);
      this.ls.deleteOrg(id).subscribe(res => {
        
          dialogConfig1.data = {
          
            response_data:res
      
          };
          //const dialogRef = this.dialog.open(DialogboxComponent, dialogConfig);
          const dialogRef = this.dialog.open(MessageboxComponent, dialogConfig1);
          dialogRef.afterClosed().subscribe(result => {
            if(result==true)
            {
              
              window.location.href = 'admin/list_org';
              //this.router.navigate(['admin/list_org']);
              
            }
            });
    });
    //this.ngOnInit();
      
    }
    });

    
        
  }
  edit_org(id)
  {
    this.router.navigate(['admin/edit_org',id]);
  }
  

}


