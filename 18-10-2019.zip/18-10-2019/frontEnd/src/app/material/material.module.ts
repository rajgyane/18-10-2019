import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  MatButtonModule, MatCardModule, MatDialogModule,MatCheckboxModule,MatExpansionModule, MatInputModule, MatTableModule,MatRadioModule,
  MatToolbarModule, MatMenuModule,MatIconModule,MatSelectModule,MatDatepickerModule, MatProgressSpinnerModule,MatListModule,MatSidenavModule
} from '@angular/material';
import { MatPaginatorModule } from '@angular/material/paginator';




@NgModule({
  declarations: [],
  imports: [
    CommonModule, 
    MatToolbarModule,
    MatButtonModule, 
    MatCardModule,
    MatInputModule,
    MatDialogModule,
    MatTableModule,
    MatMenuModule,
    MatIconModule,
    MatProgressSpinnerModule,MatSelectModule,MatRadioModule,MatCheckboxModule,MatExpansionModule,MatDatepickerModule,MatListModule,MatSidenavModule,MatPaginatorModule
    ],
    exports: [
    CommonModule,
     MatToolbarModule, 
     MatButtonModule, 
     MatCardModule, 
     MatInputModule, 
     MatDialogModule, 
     MatTableModule, 
     MatMenuModule,
     MatIconModule,
     MatProgressSpinnerModule,MatListModule,MatRadioModule,MatCheckboxModule,MatExpansionModule,MatSelectModule,MatDatepickerModule,MatSidenavModule,MatPaginatorModule
     ],
})
export class MaterialModule { }
