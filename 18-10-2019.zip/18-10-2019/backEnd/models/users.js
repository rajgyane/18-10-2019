const mongoose = require('mongoose');
const Schema = mongoose.Schema;
// Define collection and schema for Users
let Users = new Schema({
email:{type: String},   
password:{type: String},
usertype:{type: String},
status:{type:Number},
assign_role:{type: String},
org_id:{type: Object},
user_full_name:{type: String},
org_aliase:{type:String},
},{
    collection: 'users'
});
module.exports = mongoose.model('Users', Users);