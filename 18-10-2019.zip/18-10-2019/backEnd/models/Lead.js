const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Define collection and schema for Business
let Lead = new Schema({
   
    student_name:{type: String},
    mobile_no:{type: String},
    email_address:{type: String},
    class_apply:{type: String},
    country:{type: String},
    state:{type: String},
    city:{type: String},
    occupation:{type: String},
    annual_income:{type: String},
    query:{type: String},
    district:{type: String},
    pincode:{type: String},
    address1:{type: String},
    address2:{type: String},
    information_source:{type: String},
    father_name:{type: String},
    mother_name:{type: String},
    mother_occupation:{type: String},
    father_designation:{type: String},
    mother_designation:{type: String},
    father_org:{type: String},
    mother_org:{type: String},
    alter_mobile_no:{type: String},
    alter_email:{type: String},
    current_school:{type: String},
    percentage:{type: String},
    dob:{type: String},
    gender:{type: String},
    sports:{type: String},
    activity:{type: String},
    no_of_brother:{type: String},
    no_of_sister:{type: String},
    brother_school_name1:{type: String},
    brother_school_name2:{type: String},
    sister_school_name1:{type: String},
    sister_school_name2:{type: String},
    reason_for_change:{type: String},
    lead_source:{type: String},
    org_id:{type: mongoose.Schema.Types.ObjectId,ref:'Add_org'},
    creation_date:{type:Date},
    modify_date:{type:Date}
  
},{
    collection: 'lead'
});

module.exports = mongoose.model('Lead', Lead);