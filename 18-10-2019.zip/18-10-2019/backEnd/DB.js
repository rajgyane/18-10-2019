module.exports = {
    //DB: 'mongodb://localhost:27017/leadmanagementsystem'
    DB: 'mongodb+srv://abcd:abcd@cluster0-y0v0x.mongodb.net/leadmanagement'
 };